function dats() {
	var nama = prompt("Nama Kamu Siapa?");
	if (nama === 'Datul') {
        alert('Hai ' + nama + ' selamat datang')
    }
    else {
        window.location = "aa.html"
    }
}